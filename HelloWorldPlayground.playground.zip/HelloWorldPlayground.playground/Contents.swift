//: Playground - noun: a place where people can play

import UIKit

var str = "Hello World!"

print("Hello World!")

